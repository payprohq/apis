package com.lambda.paypro.demo

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.gson.Gson
import mn.lambda.paypro.sdk.PayProApi
import mn.lambda.paypro.sdk.PayProResponse
import mn.lambda.paypro.sdk.payment.PaymentOptions
import mn.lambda.paypro.sdk.printer.ReceiptType

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<Button>(R.id.cardPayment).setOnClickListener {
            val amount = findViewById<EditText>(R.id.etAmount).text.toString().toDouble()
            val options = PaymentOptions(1, true)
            PayProApi().payment(this, amount, options){ result ->
                this.runOnUiThread {
                    when (result) {
                        is PayProResponse.Success -> {
                            println(result.data.merchantId)
                            println(result.data.terminalId)
                            println(result.data.amount)
                            println(result.data.maskedPAN)
                            println(result.data.traceno)
                            println(result.data.systemRef)
                            println(result.data.approveCode)
                            println(result.data.date)
                            Toast.makeText(
                                this@MainActivity,
                                "Гүйлгээ амжилттай",
                                Toast.LENGTH_LONG
                            ).show()
                        }

                        is PayProResponse.Error -> {
                            println("Payment failed: ${result.message}")
                            Toast.makeText(
                                this@MainActivity,
                                result.message,
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }
            }
        }

        findViewById<Button>(R.id.readCardUid).setOnClickListener {
            Toast.makeText(
                this@MainActivity,
                "Картаа уншуулна уу",
                Toast.LENGTH_LONG
            ).show()
            PayProApi().readCardUID(this, 10) {
                this.runOnUiThread {
                    when(it) {
                        is PayProResponse.Success -> {
                            println(it.data.uid)
                            Toast.makeText(
                                this@MainActivity,
                                "UID: " + it.data.uid,
                                Toast.LENGTH_LONG
                            ).show()
                        }
                        is PayProResponse.Error -> {
                            println("read card serial failed")
                            Toast.makeText(
                                this@MainActivity,
                                it.message,
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }
            }
        }

        findViewById<Button>(R.id.getDeviceInfo).setOnClickListener {
            PayProApi().getDeviceInfo(this) { info ->
                this.runOnUiThread {
                    when(info) {
                        is PayProResponse.Success -> {
                            println(info.data.serialNumber)
                            Toast.makeText(
                                this@MainActivity,
                                "SN: " + info.data.serialNumber,
                                Toast.LENGTH_LONG
                            ).show()
                        }
                        is PayProResponse.Error -> {
                            println("get device info failed!")
                            Toast.makeText(
                                this@MainActivity,
                                info.message,
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }
            }
        }


        findViewById<Button>(R.id.printReceipt).setOnClickListener {
            print()
        }


    }
    val printer = SalePrinter()

    fun print(){
        // Баримт хэвлэхийн өмнө getPrintLines функцыг заавал дуудах
        printer.getPrintLines(this, true)
        val gson = Gson()
        val data = gson.toJson(printer)
        Log.d("PayPRO Demo", "Data: $data")

        PayProApi().print(this, data) {
            this.runOnUiThread {
                when (it) {
                    is PayProResponse.Success -> {
                        if (printer.receiptType == ReceiptType.CUSTOMER_COPY) {
                            AlertDialog.Builder(this)
                                .setTitle(title)
                                .setMessage("Мерчантын хувь хэвлэх үү?")
                                .setPositiveButton("Тийм") { dialog, _ ->
                                    // Print merchant copy
                                    printer.receiptType = ReceiptType.MERCHANT_COPY
                                    print()
                                    dialog.dismiss()
                                }
                                .setNegativeButton("Үгүй") { dialog, _ ->
                                    dialog.dismiss()
                                }
                                .show()
                        }
                    }

                    is PayProResponse.Error -> {
                        Toast.makeText(this, it.message, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }

    }
}