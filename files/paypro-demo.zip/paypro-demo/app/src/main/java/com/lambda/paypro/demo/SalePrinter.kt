package com.lambda.paypro.demo

import mn.lambda.paypro.sdk.printer.PrintItemAlign
import mn.lambda.paypro.sdk.printer.PrintPaperSkipItem
import mn.lambda.paypro.sdk.printer.PrintQrCodeItem
import mn.lambda.paypro.sdk.printer.PrintTextItem
import mn.lambda.paypro.sdk.printer.Receipt
import mn.lambda.paypro.sdk.printer.ReceiptType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


class SalePrinter(): Receipt() {
    override fun getSubTitle(): String {
        return if (receiptType === ReceiptType.MERCHANT_COPY) "БАЙГУУЛЛАГЫН ХУВЬ" else "ХЭРЭГЛЭГЧИЙН ХУВЬ"
    }

    override val SPLITTER: String
        get() = "-----------------------------------------------------"

    override fun printContent() {
        val labelWidth = 40
        val valueWidth = 60
        val textSize = 19f
        val labelAlign = PrintItemAlign.LEFT
        val valueAlign = PrintItemAlign.RIGHT

        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

        printPair("НЭР", "Lorem Ipsum")
        printPair("ТТД", "1234567")
        printPair("ОГНОО", sdf.format(Date()))
        printPair("ДУГААР", "ABC-1234")


        val productTextSize = 18f
        addLine(
            PrintTextItem("БАРАА", productTextSize, false, 25, labelAlign),
            PrintTextItem("ТОО", productTextSize, false, 15, labelAlign),
            PrintTextItem("ҮНЭ", productTextSize, false, 25, valueAlign),
            PrintTextItem("ДҮН", productTextSize, false, 35, valueAlign))
        printSplitter()

        addLine(
            PrintTextItem("Бараа 1", productTextSize, false, 25, labelAlign),
            PrintTextItem("2ш", productTextSize, false, 15, labelAlign),
            PrintTextItem("1,500", productTextSize, false, 25, valueAlign),
            PrintTextItem("3,000", productTextSize, false, 35, valueAlign))

        addLine(PrintPaperSkipItem(10f))
        addLine(PrintTextItem("ТӨЛБӨРИЙН ХЭЛБЭР", textSize, true, 100, labelAlign))
        printSplitter()
        addLine(
            PrintTextItem("Карт", textSize, false, valueWidth, labelAlign),
            PrintTextItem("3000", textSize, false,  labelWidth, valueAlign))


        addLine(PrintQrCodeItem("lorem ipsum paypro sdk", 240, 100, PrintItemAlign.CENTER))
        addLine(PrintTextItem("БАЯРЛАЛАА.", 18f, false, 100, PrintItemAlign.CENTER))
        addLine(PrintPaperSkipItem(10f))
    }
}
