package com.lambda.paypro.demo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import mn.lambda.paypro.sdk.printer.PrintItemAlign;
import mn.lambda.paypro.sdk.printer.PrintPaperSkipItem;
import mn.lambda.paypro.sdk.printer.PrintQrCodeItem;
import mn.lambda.paypro.sdk.printer.PrintTextItem;
import mn.lambda.paypro.sdk.printer.Receipt;
import mn.lambda.paypro.sdk.printer.ReceiptType;

public class SalePrinter extends Receipt {

    @Override
    public String getSubTitle() {
        return getReceiptType() == ReceiptType.MERCHANT_COPY
                ? "БАЙГУУЛЛАГЫН ХУВЬ"
                : "ХЭРЭГЛЭГЧИЙН ХУВЬ";
    }

    @Override
    public String getSPLITTER() {
        return "-----------------------------------------------------";
    }

    @Override
    public void printContent() {
        int labelWidth = 40;
        int valueWidth = 60;
        float textSize = 19f;
        int labelAlign = PrintItemAlign.INSTANCE.getLEFT();
        int valueAlign = PrintItemAlign.INSTANCE.getRIGHT();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());

        printPair("НЭР", "Lorem Ipsum", labelWidth, textSize, false);
        printPair("ТТД", "1234567", labelWidth, textSize, false);
        printPair("ОГНОО", sdf.format(new Date()), labelWidth, textSize, false);
        printPair("ДУГААР", "ABC-1234", labelWidth, textSize, false);

        float productTextSize = 18f;
        addLine(
                new PrintTextItem("БАРАА", productTextSize, false, 25, labelAlign),
                new PrintTextItem("ТОО", productTextSize, false, 15, labelAlign),
                new PrintTextItem("ҮНЭ", productTextSize, false, 25, valueAlign),
                new PrintTextItem("ДҮН", productTextSize, false, 35, valueAlign)
        );
        printSplitter();

        addLine(
                new PrintTextItem("Бараа 1", productTextSize, false, 25, labelAlign),
                new PrintTextItem("2ш", productTextSize, false, 15, labelAlign),
                new PrintTextItem("1,500", productTextSize, false, 25, valueAlign),
                new PrintTextItem("3,000", productTextSize, false, 35, valueAlign)
        );

        addLine(new PrintPaperSkipItem(10f));
        addLine(new PrintTextItem("ТӨЛБӨРИЙН ХЭЛБЭР", textSize, true, 100, labelAlign));
        printSplitter();
        addLine(
                new PrintTextItem("Карт", textSize, false, valueWidth, labelAlign),
                new PrintTextItem("3000", textSize, false, labelWidth, valueAlign)
        );

        addLine(new PrintQrCodeItem("lorem ipsum paypro sdk", 240, 100, PrintItemAlign.INSTANCE.getCENTER()));
        addLine(new PrintTextItem("БАЯРЛАЛАА.", 18f, false, 100, PrintItemAlign.INSTANCE.getCENTER()));
        addLine(new PrintPaperSkipItem(10f));
    }
}
