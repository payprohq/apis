package com.lambda.paypro.demo;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.gson.Gson;

import mn.lambda.paypro.sdk.DeviceInfo;
import mn.lambda.paypro.sdk.NFCCard;
import mn.lambda.paypro.sdk.PayProApi;
import mn.lambda.paypro.sdk.PayProResponse;
import mn.lambda.paypro.sdk.payment.card.CardPaymentResult;
import mn.lambda.paypro.sdk.printer.ReceiptType;

public class MainActivity extends AppCompatActivity {

    private final String bank = "xac";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        this.findViewById(R.id.cardPayment).setOnClickListener(v-> {
            EditText etAmount = this.findViewById(R.id.etAmount);
            double amount = Double.parseDouble(etAmount.getText().toString());
            new PayProApi(bank).cardPayment(this, amount, result -> {
                runOnUiThread(() -> {
                    if (result instanceof PayProResponse.Success) {
                        CardPaymentResult data = ((PayProResponse.Success<CardPaymentResult>) result).getData();
                        Log.d("PayPRO Demo", data.getMerchantId());
                        Log.d("PayPRO Demo", data.getTerminalId());
                        Log.d("PayPRO Demo", "" + data.getAmount());
                        Log.d("PayPRO Demo", data.getMaskedPAN());
                        Log.d("PayPRO Demo", data.getTraceno());
                        Log.d("PayPRO Demo", data.getSystemRef());
                        Log.d("PayPRO Demo", data.getApproveCode());

                        Toast.makeText(MainActivity.this, "Гүйлгээ амжилттай", Toast.LENGTH_LONG).show();

                    } else if (result instanceof PayProResponse.Error) {
                        String errorMessage = ((PayProResponse.Error<CardPaymentResult>) result).getMessage();
                        System.out.println("payment failed failed! reason -> " + errorMessage);
                        Toast.makeText(MainActivity.this, "Гүйлгээ амжилтгүй: " + errorMessage, Toast.LENGTH_LONG).show();
                    }
                });
                return null;
            });
        });

        this.findViewById(R.id.readCardUid).setOnClickListener(v -> {
            new PayProApi(bank).readCardUID(MainActivity.this, 10, nfcCardPayProResponse -> {
                runOnUiThread(() -> {
                    if (nfcCardPayProResponse instanceof PayProResponse.Success) {
                        NFCCard data = ((PayProResponse.Success<NFCCard>) nfcCardPayProResponse).getData();
                        String msg = "readCardUID: " + data.getUid() + " : " + data.getUidDec();
                        Log.d("PayPro", msg);
                        Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
                    } else if (nfcCardPayProResponse instanceof PayProResponse.Error) {
                        String errorMessage = ((PayProResponse.Error<NFCCard>) nfcCardPayProResponse).getMessage();
                        Log.d("PayPRO", "get card serial failed!");
                            Toast.makeText(MainActivity.this, errorMessage, Toast.LENGTH_LONG).show();
                    }
                });
                return null;
            });
        });

        this.findViewById(R.id.getDeviceInfo).setOnClickListener(v-> {
            new PayProApi(bank).getDeviceInfo(this, info -> {
                runOnUiThread(() -> {
                    if (info instanceof PayProResponse.Success) {
                        DeviceInfo data = ((PayProResponse.Success<DeviceInfo>) info).getData();
                        System.out.println(data.getSerialNumber());
                        Toast.makeText(MainActivity.this, "SN: " + data.getSerialNumber(), Toast.LENGTH_LONG).show();
                    } else if (info instanceof PayProResponse.Error) {
                        System.out.println("get device info failed!");
                    }
                });
                return null;
            });
        });

        this.findViewById(R.id.printReceipt).setOnClickListener(v-> {
            print();
        });
    }

    private final SalePrinter printer = new SalePrinter();

    private void print() {
        // Prepare printable lines (side effects inside your SDK)
        printer.getPrintLines(this, true);

        Gson gson = new Gson();
        String data = gson.toJson(printer);
        Log.d("PayPRO Demo", "Data: " + data);

        new PayProApi(bank).print(this, data, resp -> {
            runOnUiThread(() -> {
                if (resp instanceof PayProResponse.Success) {
                    if (printer.getReceiptType() == ReceiptType.CUSTOMER_COPY) {
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle(getTitle())
                                .setMessage("Мерчантын хувь хэвлэх үү?")
                                .setPositiveButton("Тийм", (dialog, which) -> {
                                    // Print merchant copy
                                    printer.setReceiptType(ReceiptType.MERCHANT_COPY);
                                    print();
                                    dialog.dismiss();
                                })
                                .setNegativeButton("Үгүй", (dialog, which) -> dialog.dismiss())
                                .show();
                    }
                } else if (resp instanceof PayProResponse.Error) {
                    String msg = ((PayProResponse.Error<?>) resp).getMessage();
                    Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
                }
            });
            return null;
        });
    }

}